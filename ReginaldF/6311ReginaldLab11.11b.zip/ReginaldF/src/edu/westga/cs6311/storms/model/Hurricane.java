package edu.westga.cs6311.storms.model;

/**
 * Manages information (name and wind speed) about a Hurricane
 *
 * **********************************************
 * ***  DO NOT MODIFY THE CODE IN THIS CLASS  ***
 * ********************************************** 
 * @author 	CS6311 
 * @version	Fall 2023
 *
 */
public class Hurricane {
	private String name;
	private int windSpeed;
	
	/**
	 * Initializes the name and wind speed to the value of
	 * 	the corresponding parameters
	 * @param	name		The Hurricane's name
	 * @param	windSpeed	The Hurricane's wind speed
	 */
	public Hurricane(String name, int windSpeed) {
		if (windSpeed < 74) {
			windSpeed = 74;
		}
		this.name = name;
		this.windSpeed = windSpeed;
	}
	
	/**
	 * Accessor for Hurricane's name
	 * 
	 * @return	The Hurricane's name
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Accessor for Hurricane's wind speed
	 * 
	 * @return	The Hurricane's wind speed
	 */
	public int getWindSpeed() {
		return this.windSpeed;
	}
	
	/**
	 * Returns a String representation of the Hurricane
	 * 
	 * @return	A String representation of the Hurricane
	 * 			including its name and wind speed
	 */
	public String toString() {
		return "Hurricane " + this.name 
				+ " with wind speed: " + this.windSpeed;
	}
}
