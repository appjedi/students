package edu.westga.cs6311.storms.model;

import java.util.ArrayList;
import java.util.List;
/**
 * Manages Array List of Hurricanes
 *
 * @author 	CS6311 
 * @version	Fall 2023
 *
 */
public class StormSeason {
	private List<Hurricane>theHurricanes;
	
	/**
	 * Initializes the array list of Hurricanes
	 */
	public StormSeason()
	{
		this.theHurricanes = new ArrayList<Hurricane>();
	}

	/**
	 * Add hurricane to array list
	 * 
	 * @return	void
	 */
	public void addHurricane(Hurricane newHurricane)
	{
		if(newHurricane==null)
		{
			return;
		}
		this.theHurricanes.add(newHurricane);
	}
	
	/**
	 * Returns a String representation of all the Hurricanes
	 * 
	 * @return	A String representation of all the Hurricanes
	 * 			including its name and wind speed
	 */
	public String toString()
	{
		String hurricanes="";
		for(Hurricane h:theHurricanes)
		{
			hurricanes+= h+System.lineSeparator();
		}
		return hurricanes;
	}
	
	/**
	 * Returns highest speed by any of the Hurricanes 
	 * 
	 * @return	A int with the highest speed by any of the Hurricanes 
	 */
	public int getMaximumSpeed()
	{
		int maxSpeed=0;
		for(Hurricane h:theHurricanes)
		{
			if(h.getWindSpeed()>maxSpeed)
			{
				maxSpeed=h.getWindSpeed();
			}
		} 
		return maxSpeed;
	}
	
	/**
	 * Returns lowest speed by any of the Hurricanes 
	 * 
	 * @return	A int with the lowest speed by any of the Hurricanes 
	 */
	public int getMinimumSpeed()
	{
		int minSpeed=Integer.MAX_VALUE;
		for(Hurricane h:theHurricanes)
		{
			if(h.getWindSpeed()<minSpeed)
			{
				minSpeed=h.getWindSpeed();
			}
		} 
		return minSpeed;
	}
	
	/**
	 * Returns average speed by any of the Hurricanes 
	 * 
	 * @return	A double with the average speed by any of the Hurricanes 
	 */
	public double getAverageSpeed() 
	{
		int count = theHurricanes.size();
		int sumWindSpeed=0;
		for(Hurricane h:theHurricanes)
		{
			sumWindSpeed +=h.getWindSpeed();
		} 
		return (double)sumWindSpeed/count;
	}
	/**	
	* returns a simple, 5-element array with the counts for each of the
	* Hurricane Categories (1, 2, 3, 4, and 5), based on the Saffir-Simpson scale
	*
	* @return simple, 5-element array of ints.
	*/
	private int[] calculateCategoryBreakdown() 
	{
		int[]categoryBreakdown= {0,0,0,0,0};
		
		for(Hurricane h:theHurricanes)
		{
			if(h.getWindSpeed()>=157)
			{
				categoryBreakdown[4]++;
			}
			else if(h.getWindSpeed()>=130)
			{
				categoryBreakdown[3]++;
			}
			else if(h.getWindSpeed()>=111)
			{
				categoryBreakdown[2]++;
			}
			else if(h.getWindSpeed()>=96)
			{
				categoryBreakdown[1]++;
			}else {
				categoryBreakdown[0]++;
			}
		}
		return categoryBreakdown;
	}

	/**
	 * Returns a String that lists the category number and the count of storms
	 * with wind speeds in that category
	 * 
	 * @return	String that lists the category number and the count of storms
	 *  		with wind speeds in that category.
	 */
	public String getCategoryBreakdown() {
		int[]categoryBreakdown=calculateCategoryBreakdown() ;
		
		String breakdown ="Category 1: "+categoryBreakdown[0]+System.lineSeparator();
		breakdown += "Category 2: "+categoryBreakdown[1]+System.lineSeparator();
		breakdown += "Category 3: "+categoryBreakdown[2]+System.lineSeparator();
		breakdown += "Category 4: "+categoryBreakdown[3]+System.lineSeparator();
		breakdown += "Category 5: "+categoryBreakdown[4]+System.lineSeparator();

		return breakdown;
	}
	
	/**
	 * Returns a String with number of * based on number passed in
	 * 	  
	 * @param int number.  Number of * to return as a string.
	 * 
	 * @return	String with number of * based on number passed in.
	 */
	private String makeStarRow(int number) 
	{
		String starRow = "";
		for (int row=0;row<number;row++)
		{
			starRow+="*";
		}
		return starRow;
	}

	/**
	 * Returns a String holding a horizontal histogram where each category will
     * be displayed on its own line with an * for every storm with that category classification
	 * 	  
	 * 
	 * @return	String holding a horizontal histogram where each category will
     * 			be displayed on its own line with an * for every storm with that category classification
	 */
	public String getCategoryHistogram() 
	{
		String histogram="";

		int[]categoryBreakdown=calculateCategoryBreakdown() ;
		for (int number:categoryBreakdown)
		{
			
			histogram+=this.makeStarRow(number)+ System.lineSeparator();
		}
		return histogram;
	}
}
