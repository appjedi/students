package edu.westga.cs6311.storms.model;

public class TestStormSeason {

	public static void main(String[] args) {
		/**
		 * Create StormSeason object
		 */
		StormSeason list = new StormSeason();
		
		/**
		 * Create five test hurricane cases
		 */
		Hurricane h=new Hurricane ("Sally",80);
		list.addHurricane(h);
		h=new Hurricane ("William",157);
		list.addHurricane(h);
		h=new Hurricane ("Tommy",102);
		list.addHurricane(h);
		h=new Hurricane ("Raymond",99);
		list.addHurricane(h);
		h=new Hurricane ("Oscar",139);
		list.addHurricane(h);
		
		/**
		 * List all Hurricanes using toString method. 
		 */
		System.out.println(list);
		
		
		/**
		 * Test minimum speed vs. actual minimum speed
		 */
		System.out.println ("Should give minimum speed of: 80");
		System.out.println ("Actual minimum speed:         "+list.getMinimumSpeed());
		System.out.println("");
		
		/**
		 * Test maximum speed vs. actual maximum speed
		 */
		System.out.println ("Should give maximum speed of: 157");
		System.out.println ("Actual maximum speed:         "+list.getMaximumSpeed());
		System.out.println("");

		/**
		 * Test average speed vs. actual average speed
		 */
		System.out.println ("Should give average speed of: 115.4");
		System.out.println ("Actual average speed:         "+list.getAverageSpeed());	
		System.out.println("");

		/**
		 * Display category breakdown.
		 */
		System.out.println(list.getCategoryBreakdown());
		
		/**
		 * Display category histogram.
		 */
		System.out.println(list.getCategoryHistogram());

	}

}
