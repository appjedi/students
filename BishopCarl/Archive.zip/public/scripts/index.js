console.log("index.js");
const divContent = document.getElementById("divContent");

const pageLoad = async () => {
    divContent.innerHTML = "JavaScript from Page Load";
}


//pageLoad();